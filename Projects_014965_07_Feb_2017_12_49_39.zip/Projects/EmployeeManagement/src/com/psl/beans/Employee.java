package com.psl.beans;

import java.util.Date;

public class Employee extends Person {
	private int empId;
	private String empName;
	private float salary;
	private Date joinDate;
	private float grade;
	private String gender;
	private float bonus;
	private Address address ;
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public float getGrade() {
		return grade;
	}

	public void setGrade(float grade) {
		this.grade = grade;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {

		this.gender = gender;
		if (gender.equalsIgnoreCase("male")) {
			setTitle("Mr.");
		} else {
			setTitle("Miss");
		}
	}

	public float getBonus() {
		return bonus;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void calculateBonus() {

		if (grade < 3.3) {
			bonus = (float) (salary * 0.1);
		} else {
			bonus = salary * 0.12f;
		}
	}
}
