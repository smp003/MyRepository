package com.psl.client;

import java.util.Date;

import com.psl.beans.Address;
import com.psl.beans.Employee;

public class Tester {

	public static void main(String[] args) {
		
	Employee emp=new Employee();
	System.out.println(emp.getEmpId());
	
	emp.setEmpId(101);
	emp.setEmpName("Teena");
	emp.setGender("Female");
	emp.setJoinDate(new Date());
	emp.setSalary(23000);
	emp.setGrade(3.3f);
	Address add=new Address();
	emp.setAddress(add);
	emp.getAddress().setCity("Pune");
	emp.getAddress().setLandmark("Opp to City Post");
	emp.calculateBonus();
	
	System.out.println(" bonus "+emp.getBonus());
	System.out.println("Title :"+emp.getTitle());
	System.out.println(emp.getAddress().getCity());	

	}

}
