package com.test;
class Person{
	Person(){
		System.out.println(" person called...");
	}
}
class Employee extends Person{
	
	private int empId;
	
	 class Address{
		 String city="Pune";
	}
	
	static{
		System.out.println(" static block....");
	}
	{
		empId=10;
		System.out.println(" instance block....");
	}
	
	public Employee() {
	
	
		System.out.println(" const called....");
	}
	
	public Employee( int empId) {
		this.empId=empId;
		System.out.println(" param const called....");
		
	}
	
	public void setEmpId(int empId) {
		
		this.empId = empId;
	}
	public int getEmpId() {
		return empId;
	}
}

public class Demo {

	public static void main(String[] args) {
	Employee e=	new Employee(10);
	System.out.println("empID="+e.getEmpId());
	System.out.println(	new Employee().new Address().city);

	}

}
