package com.psl.client;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.psl.bean.Employee;

public class Demo1 {
	static PrintStream out;

	public static void main(String[] args) {
		/*File  file=new File("xyz/mydata/pqr/abc.txt");*/
		
		/*File source=new File("C:/Users/Public/Videos/Sample Videos/Wildlife.wmv");
		File destination =new File("copyOf"+source.getName());
		
		createFile(file);
		readFile(file);
		//copyFile(source,destination);
		
		testPrintWriter();*/
		//serializeEmployees(getEmployees(), "employees.ser");
		List<Employee>  empList=deserializeEmployees("employees.ser");
		for (Employee employee : empList) {
			System.out.println(employee);
		}
		
	}
	private static List<Employee> deserializeEmployees(String fileName) {
		List<Employee> employees=new ArrayList<>();
		
		try(ObjectInputStream out=new ObjectInputStream(new FileInputStream(fileName))){
			while(true){
			Employee employee=(Employee)out.readObject();
			if(employee==null)
				break;
			employees.add(employee);
			}
		} catch ( IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
		return employees;
	}
	static List<Employee> getEmployees(){
		Employee e1=new Employee(101, "Ram", "Pune", java.sql.Date.valueOf("2017-3-1"));
		Employee e2=new Employee(102, "Jack", "Mumbai",java.sql.Date.valueOf("2017-5-10"));
		Employee e3=new Employee(103, "Meena", "Delhi",java.sql.Date.valueOf("2017-3-5"));
		Employee e5=new Employee(104, "Ram", "Pune",java.sql.Date.valueOf("2016-8-1"));
		Employee e6=new Employee(105, "Seeta", "Pune",java.sql.Date.valueOf("2017-5-11"));
		List<Employee> empList=new ArrayList<>();
		empList.add(e1);empList.add(e2);empList.add(e3);
		empList.add(e5);
		return empList;
		
	}
	
	private static void serializeEmployees(List<Employee> emp, String fileName){
		try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(fileName))){
			for (Employee employee : emp) {
				out.writeObject(employee);
			}
			System.out.println(emp.size()+" objected stored in file");
				
		} catch ( IOException e) {
			e.printStackTrace();
		}
		
	}

	private static void testPrintWriter() {
		try (PrintWriter pw=new PrintWriter(new File("data.txt"))){
			pw.print("This is string");
			pw.println(" this will add new line at the end");
			pw.write(" other line");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}

	private static void copyFile(File source, File destination) {
				
		try(
				BufferedInputStream fin=new BufferedInputStream(new FileInputStream(source));
				BufferedOutputStream fout=new BufferedOutputStream(new FileOutputStream(destination))){
			
			byte[] data=new byte[1000];
			long startTime=System.currentTimeMillis();
			while(fin.read(data)!=-1){
				fout.write(data);
			}
			long endTime=System.currentTimeMillis();
			
			System.out.println(" File copied in "+(endTime-startTime)+"ms");
			
			
		} catch ( IOException e) {
			
			e.printStackTrace();
		}
	}

	private static void readFile(File file) {
		char[] data=new char[100];
		try(FileReader fr=new FileReader(file)){
			while((fr.read(data))!=-1){
				System.out.print(data);
			}
		} catch ( IOException e) {
			e.printStackTrace();
		}
		
	}

	private static void createFile(File file) {
		try (FileWriter  fw=new FileWriter(file)){
			fw.write("This data will be added in the file");
			fw.write("\n dddsdf asfkjasdlf asdkfjkasdklf");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(" File created.....");
		
	}

}
