package com.psl.service;

import com.exceptions.InvalidInputException;
import com.test.Calculator;

public class CalculatorService {

	public float calculate(int x, int y, int operation) throws InvalidInputException {

		Calculator cal = new Calculator();
		float result = 0;
		switch (operation) {
		case 1:
			result = cal.add(x, y);
			break;
		case 2:
			result=cal.multiplication(x, y);
			break;
		case 3:
			result=cal.divide(x, y);
			break;
		}
		return result;
	}
}
