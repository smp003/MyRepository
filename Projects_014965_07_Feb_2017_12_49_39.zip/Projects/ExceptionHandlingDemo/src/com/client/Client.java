package com.client;



import com.exceptions.InvalidInputException;
import com.psl.service.CalculatorService;

public class Client {

	public static void main(String[] args) {
		int x=10,y=0;
		try{
		CalculatorService service=new CalculatorService();
		float result= service.calculate(x, y, 1);
		System.out.println(" result :"+result);
		
		result= service.calculate(x, y, 3);
		System.out.println(" result :"+result);
		
		result= service.calculate(x, y, 2);
		System.out.println(" result :"+result);
		
		}
		catch(InvalidInputException e){
			System.out.println(e);
		}
		System.out.println(" End Of Main...");
	}

}
