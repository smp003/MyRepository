package com.exceptions;

public class InvalidInputException  extends Exception{
public InvalidInputException() {
	// TODO Auto-generated constructor stub
}
public InvalidInputException(String msg) {
	super(msg);
}
	
}
