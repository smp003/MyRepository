package com.test;

class Person extends Object{
	private String title;
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTitle() {
		return title;
	}
	@Override
	public String toString() {
		return "Person [title=" + title + "]";
	}
	
}

public class Demo1 {

	public static void main(String[] args) {
		
		
		Person p=new Person();
		System.out.println(p);
		
		
	}
	int getX(){
		return 1;
	}

}


// java -ea Demo1 hello 



