package com.test;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.exceptions.InvalidInputException;

public class Calculator {

	static Logger logger=Logger.getLogger("Calculator");
	
	static{
		logger.setLevel(Level.CONFIG);
		try {
			logger.addHandler(new FileHandler("Calculator.log",true));
		} catch (SecurityException | IOException e) {
			e.printStackTrace();
		}
	}
	public int add(int x, int y) {
		return x + y;
	}

	public int multiplication(int x, int y) {
		int result = x * y;
		return result;
	}

	public float divide(int x, int y) throws InvalidInputException {
		float result = 0;

		try{		
		result = x / y;
		}catch(Exception ex){
			logger.info(ex.getMessage());
			ex.initCause(new Throwable("Invalid input "));
			throw new InvalidInputException();
		}
		return result;
	}
}
