package com.test;

class Employee {
	private int empId;
	private String name;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String name) {
		super();
		this.empId = empId;
		this.name = name;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object o1) {
		Employee e = null;
		if (o1 instanceof Employee) {
			e = (Employee) o1;
		}
		if (e!=null && this.getEmpId() == e.getEmpId() && this.name.equals(e.getName()))
			return true;
		return false;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + "]";
	}

	
}

public class Demo3 {

	public static void main(String[] args) {

		Employee e1 = new Employee(101, "Teena");
		Employee e2 = new Employee(101, "Teena");

		String s = "Hello";
		System.out.println(e1 == e2); // reference
		System.out.println(e1.equals(s)); // contents(==)

		System.out.println(e1);
		/*
		 * String s = "hello"; s.toUpperCase(); System.out.println(s);
		 * 
		 * String s1 = "hello"; System.out.println("s1==s (refernce) :" + (s ==
		 * s1)); System.out.println("s1.equals(s) (content) :" + s.equals(s1));
		 * 
		 * String s2 = new String("hello"); System.out.println("s2==s :" + (s ==
		 * s2)); System.out.println("s2.equals(s1) :" + s2.equals(s1));
		 */

		/*
		 * StringBuffer sb=new StringBuffer("hello"); //sb.append("World");
		 * System.out.println(sb);
		 * 
		 * StringBuffer sb1=new StringBuffer("hello");
		 * 
		 * 
		 * System.out.println(sb.equals(sb1));
		 */

	}

}
