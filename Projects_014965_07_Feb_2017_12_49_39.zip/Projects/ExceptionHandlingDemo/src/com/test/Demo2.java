package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Demo2 {

	public static void main(String[] args) {
		
		
		Date utilDate =new Date();
		System.out.println("Util :"+utilDate);
		java.sql.Date sqlDate=java.sql.Date.valueOf("2017-12-2");
		System.out.println(" SQL :"+ sqlDate);
		utilDate=sqlDate;
	
		Date d=new Date(sqlDate.getTime());
		System.out.println(d);
		
		
		Calendar cal=Calendar.getInstance();
		cal.setTime(sqlDate);
		System.out.println(cal.getTime());
		
		/*cal.add(Calendar.DAY_OF_MONTH, 10);
		System.out.println(cal.getTime());*/
		
		cal.add(Calendar.YEAR, 30);
		System.out.println( getFormat(cal.getTime()));
		
		String s="5/3/2017";
		Date dd=getDate(s);
		System.out.println(dd);
		
	}
	
	
	static Date getDate(String date){
		SimpleDateFormat dt=new SimpleDateFormat("dd/MM/yy");
		dt.setLenient(false);
		Date d=null;
		try {
			d = dt.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return d;
	}
	
static	String getFormat(Date date){
		
		SimpleDateFormat dt=new SimpleDateFormat("dd/MM/yy");
		String fmtDate=dt.format(date);
		return fmtDate;
		
	}



}

