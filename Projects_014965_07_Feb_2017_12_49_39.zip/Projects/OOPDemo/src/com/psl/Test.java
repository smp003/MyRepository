package com.psl;

import java.io.IOException;

//marker interface
//funtional interface
interface A {
	int data = 10;

	public abstract void print();
}

interface B extends A{
	
}


class TestA implements A {

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

}

abstract class MyClass implements A {
	static final int data=20;
	int testI;

	public MyClass() {
		System.out.println(" Myclass .....");
	}

	void show() {
		System.out.println(" Myclass show()");

	}

	abstract void display() throws Exception;
}

class MyclassA extends MyClass {
	int testK;

	public MyclassA() {
		System.out.println("MyclassA.....");
	}

	void show(int y) {
		System.out.println(" MyclassA.. show()");

	}

 protected	void display() {
	}

	@Override
	public void print() {
		System.out.println(" Data is" +A.data);
	}

}

public class Test {

	public static void main(String[] args) {
		MyclassA a = new MyclassA();
	
	
	}
}
