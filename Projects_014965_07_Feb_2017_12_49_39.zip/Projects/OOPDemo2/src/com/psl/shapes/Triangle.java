package com.psl.shapes;

public class Triangle extends Shape implements Moveable , Bouncable{

	@Override
	public void print() {
		System.out.println("Printing Triangle.....");

	}
	@Override
	public void move() {
		System.out.println(" Triangle is moving....");
	}
	@Override
	public void bounce() {
		System.out.println(" Triangle is bouncing....");
		
	}
}
