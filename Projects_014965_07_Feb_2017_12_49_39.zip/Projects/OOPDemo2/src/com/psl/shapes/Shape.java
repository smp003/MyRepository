package com.psl.shapes;

public abstract class Shape {
 abstract public void print();

}
