package com.psl.shapes;

public class Circle extends Shape implements Bouncable {

	@Override
	public void print() {
		System.out.println(" printing Circle....");
	}

	@Override
	public void bounce() {

		System.out.println(" circle is bouncing.....");

	}

}
