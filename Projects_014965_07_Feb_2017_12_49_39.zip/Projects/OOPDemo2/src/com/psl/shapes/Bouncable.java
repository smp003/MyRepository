package com.psl.shapes;

public interface Bouncable {
public void bounce();
}
