package com.psl.shapes;

public class Square extends Shape  implements Moveable{

	@Override
	public void print() {
		System.out.println(" printing Square...");

	}
	@Override
	public void move() {
		System.out.println(" Square is moving....");
	}

}
