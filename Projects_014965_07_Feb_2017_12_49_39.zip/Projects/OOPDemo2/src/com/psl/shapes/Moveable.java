package com.psl.shapes;

public interface Moveable {
	 abstract public void move();
	  default void moveLeft(){
		  
	  }
}
