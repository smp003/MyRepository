package com.psl.ui;

import com.psl.shapes.Bouncable;
import com.psl.shapes.Moveable;
import com.psl.shapes.Shape;

public class GameCanvas {
	public void drawShape(Shape s){
		s.print();
	}
	
	public void animateShape(Shape s){
		s.print();
		if(s instanceof Moveable)
		((Moveable)s).move();
		if(s instanceof Bouncable)
		((Bouncable)s).bounce();
		
	}
	
}
