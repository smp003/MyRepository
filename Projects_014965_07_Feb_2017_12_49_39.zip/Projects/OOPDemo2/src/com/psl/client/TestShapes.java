package com.psl.client;

import com.psl.shapes.Circle;
import com.psl.shapes.Square;
import com.psl.shapes.Triangle;
import com.psl.ui.GameCanvas;

public class TestShapes {

	public static void main(String[] args) {

		GameCanvas canvas=new GameCanvas();
		// Shape s=new Square()
		Square s=new Square();
		//canvas.drawShape(s);
		Circle circle = new Circle();
		//canvas.drawShape(circle);
		Triangle triangle = new Triangle();
		//canvas.drawShape(triangle);
		
		canvas.animateShape(s);
		canvas.animateShape(circle);
		canvas.animateShape(triangle);
	}

}
