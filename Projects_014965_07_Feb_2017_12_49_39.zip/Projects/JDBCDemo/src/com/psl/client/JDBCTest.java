package com.psl.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class JDBCTest {


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 1. Loading driver
		Connection cn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			//2. define connection URL -> protocol with server and port , username, password
			String url="jdbc:mysql://localhost:3306/employeedb";
			String username="root";
			String password="root";
			//3 create connection
			cn=DriverManager.getConnection(url, username, password);
			cn.setAutoCommit(false);
			System.out.println("Connection created .."+cn);
			//4. create Statement
			Statement stmt=cn.createStatement();
			String str="insert into employee values(103,'Seeta','Pune','411001','2001-1-1')";
		
			stmt.executeUpdate(str);
			
			cn.commit();
			//String query="select * from employee where city=? and joinDate>?";
			//PreparedStatement stmt=cn.prepareStatement(query);
			/*stmt.setString(1, "Pune");
			stmt.setDate(2, java.sql.Date.valueOf("2010-1-1"));
			ResultSet rs=stmt.executeQuery();*/
			//6 process result
			
			
			
			
			
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			try {
				cn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			//7 Close connection
			try {
				if(cn!=null)
				cn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}

}
