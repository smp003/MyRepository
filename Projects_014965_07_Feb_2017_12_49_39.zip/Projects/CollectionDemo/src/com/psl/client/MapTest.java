package com.psl.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;



class Animal<T> {
  public T id;
  
  public Animal() {
	// TODO Auto-generated constructor stub
}
  public Animal(T id) {
		this.id=id;
	} 
  
  public void show(){
	  System.out.println(id);
  }
}

class Dog extends Animal {

}

class Puppy extends Dog {

}

public class MapTest {

	public static void voice(List<?> dogsList) {

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// List<Object> list=new ArrayList<Object>();

			Animal<String> animal=new Animal<String>("A1100");
			animal.show();
			
			Stack<String> st=new Stack<>();
			st.add("111");
			
 
			
			Queue<String> que=new PriorityQueue<>();
			
			que.offer("Data1");
			que.add("Data2");
			
			System.out.println(que);
			System.out.println("size "+que.size());
			System.out.println(que.peek());
			System.out.println("size "+que.size());
			System.out.println(que.poll());
			System.out.println("size "+que.size());
			
			
		/*Object[] obj = new String[5];
		List<?> list = new ArrayList<String>();

		List<Object> animalList = new ArrayList<Object>();

		voice(animalList);
		testMaps();*/
	}

	static void testMaps() {
	/*	NavigableMap<Employee, Integer> maps = new TreeMap<Employee, Integer>(
				new Comparator<Employee>() {
					@Override
					public int compare(Employee arg0, Employee arg1) {
						// TODO Auto-generated method stub
						return 0;
					}
				});*/
Hashtable<String,Integer> maps=new Hashtable<>();

    Enumeration en=maps.elements();
    
    while(en.hasMoreElements()){
    	System.out.println(en.nextElement());
    }
    
		
		System.out.println(maps);

		System.out.println(maps.keySet());

		for (String string : maps.keySet()) {
			System.out.println("key :" + string + "\tValue :"
					+ maps.get(string));
		}

		for (Entry<String, Integer> entry : maps.entrySet()) {
			System.out.println(" key :" + entry.getKey() + " Value :"
					+ entry.getValue());
		}

		System.out.println(maps.containsKey("Two"));
		System.out.println(maps.containsValue("2"));

	}
}
