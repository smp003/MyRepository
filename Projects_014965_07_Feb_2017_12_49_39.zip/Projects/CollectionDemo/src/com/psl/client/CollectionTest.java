package com.psl.client;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

class SortByNameAndId implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		int i=e1.getEmpName().compareTo(e2.getEmpName());
		if(i==0){
			i=e1.getEmpId()-e2.getEmpId();
		}
		return i;
	}
	
}
class SortByCity implements Comparator<Employee>{
	@Override
	public int compare(Employee e1, Employee e2) {
	 int i= e1.getCity().compareTo(e2.getCity());
	 if(i==0){
		 i=e1.getEmpId()-e2.getEmpId();
	 }
	 return i;
	}
}

class Employee implements Comparable<Employee> {
	private int empId;
	private String empName;
	private String city;
	private Date joinDate;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, String city) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.city = city;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", city="
				+ city + "]";
	}
	//@Override
	public int compareTo(Employee e) {
		// TODO Auto-generated method stub

		return empId-e.getEmpId();
	}
	
}


public class CollectionTest {

	public static void main(String[] args) {
		//testLists();
		//testSet();
		List<Employee> empList=getEmployees();
		
		Collections.sort(empList);
				
		for (Employee employee : empList) {
			System.out.println(employee);
		}
		
		Collections.sort(empList, new SortByCity());
		
		Set<Employee> empSet=new TreeSet<>(new SortByNameAndId());
				
		/*Set<Employee> empSet=new TreeSet<>();
		empSet.addAll(empList);
		System.out.println(" Size of EMp Set "+empSet.size());
		System.out.println(" --------- Sort By ID--------");
		for (Employee employee : empSet) {
			System.out.println(employee);
		}
		
		
		Set<Employee> empSetByName =new TreeSet<>(new SortByNameAndId());
		empSetByName.addAll(empSet);
		System.out.println(" --------- Sort By Name--------");
		for (Employee employee : empSetByName) {
			System.out.println(employee);
		}
		
		
		

		Set<Employee> empSetByCity =new TreeSet<>(new SortByCity());
		empSetByCity.addAll(empSet);
		System.out.println(" --------- Sort By City--------");
		for (Employee employee : empSetByCity) {
			System.out.println(employee);
		}
		*/
		
		
		
	}

	
	static List<Employee> getEmployees(){
		Employee e1=new Employee(101, "Ram", "Pune");
		Employee e2=new Employee(102, "Jack", "Mumbai");
		Employee e3=new Employee(103, "Meena", "Delhi");
		Employee e4=e2;
		Employee e5=new Employee(104, "Ram", "Pune");
		Employee e6=new Employee(105, "Seeta", "Pune");
		
		
		List<Employee> empList=new ArrayList<>();
		empList.add(e1);empList.add(e2);empList.add(e3);empList.add(e4);
		empList.add(e5);
	
		
		System.out.println("total emp:"+empList.size());
		return empList;
		
	}
	
	static void testSet(){
		Set<String> set =new HashSet<String>();
		set.add("10");
		set.add(null);
		/*set.add("20");
		set.add("Test");
		set.add("Hello");*/
		
	System.out.println(set.contains("20"));
		
		Set s=new TreeSet();
		s.add("Hello");
		s.add("Test1223");
		
		/*System.out.println(set.containsAll(s));*/
	/*
		Iterator<String> itr=set.iterator();
		while(itr.hasNext()){
			itr.remove()
			;
			System.out.println(itr.next());
		}*/
		
		
	}
	
	static void testLists(){
		
		List<String> list=new LinkedList<String>();
		list.add("20");
		list.add("Hello");
		list.add("34.7");
		list.add("Test");
		list.add("true");
		
		
		//iterating collection
		
		for (Object object : list) {
			if(object instanceof String)
			System.out.println(((String)object).toUpperCase());
			else
			System.out.println((object));

		}
		
		
		
		
		//iterating collection
		
				for (Object object : list) {
					if(object instanceof String)
					System.out.println(((String)object).toUpperCase());
					else
					System.out.println((object));

				}
		
		// Collections 
		
		// Collection(I) Collections (C) 
		
		
		/*// iterator
		Iterator itr=list.iterator();
		while(itr.hasNext()){
			Object obj=itr.next();
			System.out.println(obj);
		}
		
		// traditional for loop
		System.out.println(list.size());
		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}
		
		
		// listIterator
		
		ListIterator lit=list.listIterator();
		while(lit.hasNext()){
			System.out.println(lit.next());
		}*/
		
		
		
		
		
	}

}
