package com.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

interface MyInterface{
	@Deprecated
	void show();
	
default	void print(){
		System.out.println("test....");
	}
}

interface Message{
	String message(String... str);
}

class Person{
	private int id;
	private String name;
	private String age;
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public Person(int id, String name, String age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
	static public int sortByID(Person p1,Person p2){
		return p1.getId()-p2.getId();
	}
	public int sortByName(Person p1,Person p2){
		int i= p1.getName().compareTo(p2.getName());
		if(i==0){
			i= p1.getId()-p2.getId();
		}
		return i;
	}
	public int sortByAge(Person p1,Person p2){
		int i= p1.getAge().compareTo(p2.getAge());
		if(i==0){
			i= p1.getId()-p2.getId();
		}
		return i;
	}
}

public class Demo {

	public static void main(String[] args) {

		Message msg=(String... str)->{ for (String string : str) {
			System.out.println(string);
		} ;return "Welcome  "+str[0]+"! to JAVA 8";};// declaring class end
		
		
		
		System.out.println(msg.message("Ram","sdsd","sdfsdf","dsfsdf"));
		Person p=new Person();
		System.out.println("----- Persons By ID-----");
		Demo demo = new Demo();
		List<Person> personList=demo.getPersons();
		Collections.sort(personList,Person::sortByID);
		
		demo.printPersons(personList);
		Set<Person> persons=new TreeSet<>(p::sortByName);
		persons.addAll(demo.getPersons());
		System.out.println("----- Persons By Name-----");
		demo.printPersons(persons);
	
		
		
		
		
		Collections.sort(personList, p::sortByAge);
		System.out.println("----- Persons By Age-----");
		demo.printPersons(personList);
		
		
		Comparator<Person> comparator=(Person p1,Person p2)->{
			int i=p2.getName().compareTo(p1.getName());
			if(i==0){
				i=p1.getAge().compareTo(p2.getAge());
			}
			return i;
		};
		
		Collections.sort(personList,comparator);
		
		System.out.println(" by name and age ");
		demo.printPersons(personList);
		
		
		
		
		
	}
	
	void printPersons(Collection<Person> coll){
		for (Person person : coll) {
			System.out.println(person); 
		}
	}
	
	
	List<Person> getPersons(){
		Person p1=new Person(101,"Tom","23");
		Person p2=new Person(102,"Ram","45");
		Person p3=new Person(103,"Tom","24");
		Person p4=new Person(104,"Harry","23");
		Person p5=new Person(105,"Geet","25");
		
		
		List<Person> persons=new ArrayList<>();
		
		persons.add(p5);
		persons.add(p4);
		persons.add(p3);
		persons.add(p2);
		persons.add(p1);
		return persons;
				
	}

}
