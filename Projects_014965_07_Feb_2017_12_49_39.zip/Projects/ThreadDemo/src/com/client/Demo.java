package com.client;

enum Day {

	Monday(30, Month.Jan), Tuesday(10, Month.Jan), Friday, Saturday(0) {
		String getMessage() {
			return " Week End... ";
		}
	},
	Sunday(0) {
		String getMessage() {
			return " Week End... ";
		}
	};
	enum Month {
		Jan, Feb;
		Month() {
		}
	};

	Month month;
	private int value;

	private Day() {
		// TODO Auto-generated constructor stub
	}

	private Day(int value, Month mon) {
		this.value = value;
		this.month = mon;
	}

	private Day(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	String getMessage() {
		return " Week Day ";
	}
	Month getMonth(){
		return month;
	}
}
interface Message{
	void message();
}
public class Demo {

	public static void main(String... args) {
		
		Message msg=()-> System.out.println("Hello");

		msg.message();
		String s = "Monday";
		Day dd = Day.valueOf(s);
		System.out.println(dd);

		for (Day day : Day.values()) {
			System.out.println(day + " : " + day.ordinal() + "Val :"
					+ day.getValue());
			System.out.println(day.getMessage()+day.getMonth());
		}
	}

	static void foo(int x) {
		System.out.println(" int x");
	}

	static void foo(Integer x) {
		System.out.println(" Integer x");
	}

	static void foo(int... x) {
		System.out.println(" int... x");
		/*
		 * for (int i=0;i<x.length;i++) { System.out.println(x[i] ); }
		 */
		for (int i : x) {
			System.out.println(i);
		}
	}
}
