package com.client;

class Resource {

	private int number = 0;

	public int getIncNumber() {

		number++;

		try {
			Thread.sleep(400);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return number;

	}
}

class ResourceConsumer implements Runnable {
	Resource res = null;

	public ResourceConsumer(Resource res) {
		this.res = res;
	}

	public void run() {

		for (int i = 0; i < 7; i++) {
			synchronized (res) {
				System.out.println(Thread.currentThread().getName()
						+ "got number :" + res.getIncNumber());	
			}
			
		}

	}

}



public class SyncDemo {

	public static void main(String[] args) {

		Resource res = new Resource();

		Thread t1 = new Thread(new ResourceConsumer(res), " consumer1");
		Thread t2 = new Thread(new ResourceConsumer(res), " consumer2");
		Thread t3 = new Thread(new ResourceConsumer(res), " consumer3");

		t2.start();
		t1.start();
		t3.start();

	}

}
