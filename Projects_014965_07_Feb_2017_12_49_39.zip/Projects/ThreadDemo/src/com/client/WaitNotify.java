package com.client;

class Account {
	private int balance;

	void deposit(int amt) {
		balance += amt;
	}

	void withdraw(int amt) {
		balance -= amt;
	}

	public int getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}
}

class Depositor implements Runnable {

	Account account = null;

	public Depositor(Account account) {
		this.account = account;
	}

	@Override
	public void run() {

		System.out.println(Thread.currentThread().getName()
				+ " Entered in bank");
		account.deposit(10000);
		synchronized (account) {
			account.notify();		
		System.out.println(" balance after deposit " + account.getBalance());
		}
	}
}

class Withdrawer implements Runnable {
	Account account = null;

	public Withdrawer(Account account) {
		this.account = account;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()
				+ " Entered in bank");
		synchronized (account) {

			try {
				account.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		account.withdraw(10000);
		System.out.println(" balance after withdraw " + account.getBalance());
		}
	}

}

public class WaitNotify {

	public static void main(String[] args) {
		Account account = new Account();

		Depositor depositor = new Depositor(account);

		Withdrawer withdrawer = new Withdrawer(account);

		Thread t1 = new Thread(depositor, "Depositor");
		Thread t2 = new Thread(withdrawer, "Withdrawer");

		t2.start();
		
		t1.start();

	}

}
