package com.client;

class ChildThread implements Runnable{

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println(" value of i="+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}

class MyThread extends Thread{
	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println(" i*i ="+(i*i) );
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}// end of thread
}

public class ThreadTest {

	public static void main(String[] args) {

		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getPriority());
		System.out.println(Thread.currentThread().isAlive());
		System.out.println(Thread.currentThread().isDaemon());
		
		MyThread thread=new MyThread(); // born
		thread.setName("Mythread1");
		thread.setPriority(Thread.MAX_PRIORITY);
		thread.setDaemon(true);
	
		
		ChildThread t1=new ChildThread();
		Thread thread2=new Thread(t1);
		thread2.setName("RunnableThread");
		thread2.start();
		thread.start(); //wait , block, dead, running	
		
		Thread thread3=new Thread(t1);
		thread3.start();
		
		System.out.println("-------End of main------");
		
	}// end of app
	
	

}
